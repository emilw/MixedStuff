#ifndef GDBLAB_H
#define GDBLAB_H

int test();

#endif
