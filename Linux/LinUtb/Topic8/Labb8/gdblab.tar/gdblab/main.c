#include <stdio.h>

#include "gdblab.h"

int main(void)
{
	test();

	return 0;
}
