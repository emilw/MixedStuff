gcc my_add_x.c -o plus_x
