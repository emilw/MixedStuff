/* c_functions.c  */


#include <stdio.h>

#include "c.h"

void print_C()
{
	printf(C_MESSAGE);
}
