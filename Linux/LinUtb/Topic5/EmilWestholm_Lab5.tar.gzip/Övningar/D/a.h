#ifndef FILE_A
#define FILE_A


#define A_MESSAGE "A\n"

#endif
