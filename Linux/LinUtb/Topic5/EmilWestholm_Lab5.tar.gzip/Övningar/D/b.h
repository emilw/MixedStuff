#ifndef FILE_B
#define FILE_B


#define B_MESSAGE "B\n"

#endif
