gcc my_add_2.c -o plus_2
