int add(int value1, int value2){
    return value1 + value2;
}